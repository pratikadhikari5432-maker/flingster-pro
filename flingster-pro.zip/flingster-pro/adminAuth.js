const { ADMIN_PASSWORD } = require("../config/appConfig");

function adminAuth(req, res, next) {
  const incomingPassword = req.headers["x-admin-password"];

  if (!incomingPassword || incomingPassword !== ADMIN_PASSWORD) {
    return res.status(401).json({
      success: false,
      message: "Unauthorized admin access"
    });
  }

  next();
}

module.exports = adminAuth;