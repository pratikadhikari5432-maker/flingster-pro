const state = {
  waitingQueue: [],
  activePairs: new Map(),
  reports: [],
  bannedUsers: new Set(),
  premiumUsers: new Set()
};

function addToQueue(socketId) {
  if (!state.waitingQueue.includes(socketId)) {
    state.waitingQueue.push(socketId);
  }
}

function removeFromQueue(socketId) {
  state.waitingQueue = state.waitingQueue.filter((id) => id !== socketId);
}

function getQueueLength() {
  return state.waitingQueue.length;
}

function getNextMatchCandidate(excludeId) {
  state.waitingQueue = state.waitingQueue.filter((id) => id !== excludeId);
  return state.waitingQueue.shift() || null;
}

function pairUsers(userA, userB) {
  state.activePairs.set(userA, userB);
  state.activePairs.set(userB, userA);
}

function unpairUser(socketId) {
  const partnerId = state.activePairs.get(socketId);

  if (partnerId) {
    state.activePairs.delete(partnerId);
  }

  state.activePairs.delete(socketId);

  return partnerId || null;
}

function getPartner(socketId) {
  return state.activePairs.get(socketId) || null;
}

function saveReport(report) {
  state.reports.push(report);
}

function getReports() {
  return state.reports;
}

function banUser(socketId) {
  state.bannedUsers.add(socketId);
}

function isBanned(socketId) {
  return state.bannedUsers.has(socketId);
}

function getBannedCount() {
  return state.bannedUsers.size;
}

function activatePremium(socketId) {
  if (socketId) {
    state.premiumUsers.add(socketId);
  }
}

function isPremium(socketId) {
  return state.premiumUsers.has(socketId);
}

function getPremiumCount() {
  return state.premiumUsers.size;
}

function getActiveConnectionsCount() {
  return Math.floor(state.activePairs.size / 2);
}

function removeUserCompletely(socketId) {
  removeFromQueue(socketId);
  const partnerId = unpairUser(socketId);
  state.premiumUsers.delete(socketId);
  return partnerId;
}

module.exports = {
  state,
  addToQueue,
  removeFromQueue,
  getQueueLength,
  getNextMatchCandidate,
  pairUsers,
  unpairUser,
  getPartner,
  saveReport,
  getReports,
  banUser,
  isBanned,
  getBannedCount,
  activatePremium,
  isPremium,
  getPremiumCount,
  getActiveConnectionsCount,
  removeUserCompletely
};