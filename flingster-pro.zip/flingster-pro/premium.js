const express = require("express");
const router = express.Router();
const { activatePremium } = require("../utils/memoryStore");

router.post("/activate", (req, res) => {
  const { socketId } = req.body || {};

  if (!socketId) {
    return res.status(400).json({
      success: false,
      message: "socketId is required"
    });
  }

  activatePremium(socketId);

  res.json({
    success: true,
    message: "Premium activated successfully (demo mode)"
  });
});

module.exports = router;