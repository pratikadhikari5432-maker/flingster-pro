const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");

const {
  PORT,
  FRONTEND_URL,
  SITE_NAME
} = require("./config/appConfig");

const healthRoute = require("./routes/health");
const adminRoute = require("./routes/admin");
const premiumRoute = require("./routes/premium");

const {
  addToQueue,
  removeFromQueue,
  getNextMatchCandidate,
  pairUsers,
  getPartner,
  unpairUser,
  saveReport,
  isBanned,
  removeUserCompletely
} = require("./utils/memoryStore");

const app = express();
const server = http.createServer(app);

app.use(cors({
  origin: "*"
}));

app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: `${SITE_NAME} API is live`
  });
});

app.use("/health", healthRoute);
app.use("/admin", adminRoute);
app.use("/premium", premiumRoute);

const io = new Server(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

function matchUser(socket) {
  if (isBanned(socket.id)) {
    socket.emit("banned_notice");
    return;
  }

  const candidateId = getNextMatchCandidate(socket.id);

  if (!candidateId) {
    addToQueue(socket.id);
    socket.emit("waiting");
    return;
  }

  const partnerSocket = io.sockets.sockets.get(candidateId);

  if (!partnerSocket) {
    addToQueue(socket.id);
    socket.emit("waiting");
    return;
  }

  pairUsers(socket.id, partnerSocket.id);

  socket.emit("matched", { initiator: true });
  partnerSocket.emit("matched", { initiator: false });
}

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join_queue", () => {
    removeFromQueue(socket.id);
    const existingPartner = getPartner(socket.id);

    if (existingPartner) {
      unpairUser(socket.id);
    }

    matchUser(socket);
  });

  socket.on("next_user", () => {
    removeFromQueue(socket.id);

    const partnerId = unpairUser(socket.id);
    if (partnerId) {
      const partnerSocket = io.sockets.sockets.get(partnerId);
      if (partnerSocket) {
        partnerSocket.emit("partner_disconnected");
      }
    }

    socket.emit("queue_reset");
    matchUser(socket);
  });

  socket.on("send_message", ({ message }) => {
    const partnerId = getPartner(socket.id);
    if (!partnerId) return;

    const partnerSocket = io.sockets.sockets.get(partnerId);
    if (!partnerSocket) return;

    partnerSocket.emit("receive_message", {
      sender: "Stranger",
      message
    });
  });

  socket.on("webrtc_offer", ({ offer }) => {
    const partnerId = getPartner(socket.id);
    if (!partnerId) return;

    const partnerSocket = io.sockets.sockets.get(partnerId);
    if (!partnerSocket) return;

    partnerSocket.emit("webrtc_offer", { offer });
  });

  socket.on("webrtc_answer", ({ answer }) => {
    const partnerId = getPartner(socket.id);
    if (!partnerId) return;

    const partnerSocket = io.sockets.sockets.get(partnerId);
    if (!partnerSocket) return;

    partnerSocket.emit("webrtc_answer", { answer });
  });

  socket.on("ice_candidate", ({ candidate }) => {
    const partnerId = getPartner(socket.id);
    if (!partnerId) return;

    const partnerSocket = io.sockets.sockets.get(partnerId);
    if (!partnerSocket) return;

    partnerSocket.emit("ice_candidate", { candidate });
  });

  socket.on("report_user", ({ reason }) => {
    const partnerId = getPartner(socket.id);

    saveReport({
      reporter: socket.id,
      reported: partnerId,
      reason: reason || "No reason provided",
      time: new Date().toISOString()
    });

    socket.emit("report_saved");
  });

  socket.on("disconnect", () => {
    console.log("User disconnected:", socket.id);

    removeFromQueue(socket.id);

    const partnerId = removeUserCompletely(socket.id);

    if (partnerId) {
      const partnerSocket = io.sockets.sockets.get(partnerId);
      if (partnerSocket) {
        partnerSocket.emit("partner_disconnected");
      }
    }
  });
});

server.listen(PORT, () => {
  console.log(`${SITE_NAME} backend running on port ${PORT}`);
});