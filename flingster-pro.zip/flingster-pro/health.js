const express = require("express");
const router = express.Router();
const { SITE_NAME } = require("../config/appConfig");

router.get("/", (req, res) => {
  res.json({
    success: true,
    message: `${SITE_NAME} backend is running`
  });
});

module.exports = router;