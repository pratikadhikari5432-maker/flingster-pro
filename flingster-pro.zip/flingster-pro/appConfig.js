require("dotenv").config();

module.exports = {
  PORT: process.env.PORT || 3000,
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || "change_this_super_secret",
  FRONTEND_URL: process.env.FRONTEND_URL || "http://localhost",
  SITE_NAME: process.env.SITE_NAME || "Flingster Pro"
};