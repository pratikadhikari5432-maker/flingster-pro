const express = require("express");
const router = express.Router();
const adminAuth = require("../middleware/adminAuth");
const {
  getQueueLength,
  getActiveConnectionsCount,
  getReports,
  getBannedCount,
  getPremiumCount
} = require("../utils/memoryStore");

router.get("/stats", adminAuth, (req, res) => {
  res.json({
    success: true,
    data: {
      waitingUsers: getQueueLength(),
      activeConnections: getActiveConnectionsCount(),
      reports: getReports().length,
      bannedUsers: getBannedCount(),
      premiumUsers: getPremiumCount()
    }
  });
});

router.get("/reports", adminAuth, (req, res) => {
  res.json({
    success: true,
    reports: getReports()
  });
});

module.exports = router;