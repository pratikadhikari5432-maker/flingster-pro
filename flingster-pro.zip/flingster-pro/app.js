const BACKEND_URL = "http://162.246.17.80:3000";

const socket = io(BACKEND_URL, {
  transports: ["websocket", "polling"]
});

const statusText = document.getElementById("statusText");
const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");
const startBtn = document.getElementById("startBtn");
const nextBtn = document.getElementById("nextBtn");
const reportBtn = document.getElementById("reportBtn");
const premiumBtn = document.getElementById("premiumBtn");
const sendBtn = document.getElementById("sendBtn");
const messageInput = document.getElementById("messageInput");
const messages = document.getElementById("messages");

let localStream = null;
let peerConnection = null;
let isInitiator = false;

const rtcConfig = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" }
  ]
};

async function initMedia() {
  try {
    localStream = await navigator.mediaDevices.getUserMedia({
      video: true,
      audio: true
    });
    localVideo.srcObject = localStream;
    setStatus("Camera ready");
  } catch (error) {
    console.error(error);
    setStatus("Camera permission denied / failed");
    alert("Please allow camera and microphone permissions.");
  }
}

function setStatus(text) {
  statusText.textContent = text;
}

function addMessage(sender, text) {
  const row = document.createElement("div");
  row.className = "message-row";
  row.innerHTML = `<strong>${sender}:</strong> ${text}`;
  messages.appendChild(row);
  messages.scrollTop = messages.scrollHeight;
}

function resetPeer() {
  if (peerConnection) {
    peerConnection.onicecandidate = null;
    peerConnection.ontrack = null;
    peerConnection.close();
    peerConnection = null;
  }
  remoteVideo.srcObject = null;
}

function createPeerConnection() {
  resetPeer();

  peerConnection = new RTCPeerConnection(rtcConfig);

  if (localStream) {
    localStream.getTracks().forEach(track => {
      peerConnection.addTrack(track, localStream);
    });
  }

  peerConnection.onicecandidate = (event) => {
    if (event.candidate) {
      socket.emit("ice_candidate", { candidate: event.candidate });
    }
  };

  peerConnection.ontrack = (event) => {
    remoteVideo.srcObject = event.streams[0];
  };
}

async function createOffer() {
  if (!peerConnection) createPeerConnection();

  const offer = await peerConnection.createOffer();
  await peerConnection.setLocalDescription(offer);
  socket.emit("webrtc_offer", { offer });
}

async function createAnswer(offer) {
  if (!peerConnection) createPeerConnection();

  await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
  const answer = await peerConnection.createAnswer();
  await peerConnection.setLocalDescription(answer);
  socket.emit("webrtc_answer", { answer });
}

async function receiveAnswer(answer) {
  if (!peerConnection) return;
  await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
}

startBtn.addEventListener("click", async () => {
  if (!localStream) {
    await initMedia();
  }
  setStatus("Searching for stranger...");
  socket.emit("join_queue");
});

nextBtn.addEventListener("click", () => {
  resetPeer();
  setStatus("Finding next stranger...");
  socket.emit("next_user");
});

reportBtn.addEventListener("click", () => {
  socket.emit("report_user", { reason: "User reported from UI" });
  alert("Report submitted.");
});

premiumBtn.addEventListener("click", async () => {
  try {
    const res = await fetch(`${BACKEND_URL}/premium/activate`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        socketId: socket.id
      })
    });

    const data = await res.json();
    alert(data.message || "Premium response received");
  } catch (err) {
    console.error(err);
    alert("Premium activation failed");
  }
});